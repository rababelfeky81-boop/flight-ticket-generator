
import React from 'react';
import type { TicketData } from '../types';

interface TicketFormProps {
  data: TicketData;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}

const InputField: React.FC<{ label: string; name: keyof TicketData; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; type?: string; placeholder?: string }> = ({ label, name, value, onChange, type = 'text', placeholder }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-gray-600 mb-1">{label}</label>
    <input
      type={type}
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder || `Enter ${label}`}
      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent transition-shadow"
    />
  </div>
);


export const TicketForm: React.FC<TicketFormProps> = ({ data, onChange }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg space-y-6">
      <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Ticket Details</h2>
      
      <form className="space-y-6">
        <fieldset className="border border-gray-200 p-4 rounded-lg">
          <legend className="text-lg font-semibold px-2 text-gray-700">Passenger & Booking</legend>
          <div className="space-y-4 pt-2">
            <InputField label="Full Name" name="fullName" value={data.fullName} onChange={onChange} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InputField label="Booking Reference" name="bookingReference" value={data.bookingReference} onChange={onChange} />
              <InputField label="Ticket Number" name="ticketNumber" value={data.ticketNumber} onChange={onChange} />
            </div>
          </div>
        </fieldset>

        <fieldset className="border border-gray-200 p-4 rounded-lg">
          <legend className="text-lg font-semibold px-2 text-gray-700">Flight Itinerary</legend>
          <div className="space-y-4 pt-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InputField label="Departure City" name="departureCity" value={data.departureCity} onChange={onChange} />
              <InputField label="Departure Airport (Code)" name="departureAirport" value={data.departureAirport} onChange={onChange} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <InputField label="Arrival City" name="arrivalCity" value={data.arrivalCity} onChange={onChange} />
              <InputField label="Arrival Airport (Code)" name="arrivalAirport" value={data.arrivalAirport} onChange={onChange} />
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label="Departure Date & Time" name="departureDateTime" value={data.departureDateTime} onChange={onChange} type="datetime-local"/>
                <InputField label="Arrival Date & Time" name="arrivalDateTime" value={data.arrivalDateTime} onChange={onChange} type="datetime-local" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label="Flight Number" name="flightNumber" value={data.flightNumber} onChange={onChange} />
                <InputField label="Duration" name="duration" value={data.duration} onChange={onChange} />
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label="Terminal" name="terminal" value={data.terminal} onChange={onChange} />
                <InputField label="Class" name="flightClass" value={data.flightClass} onChange={onChange} />
            </div>
          </div>
        </fieldset>
        
        <fieldset className="border border-gray-200 p-4 rounded-lg">
          <legend className="text-lg font-semibold px-2 text-gray-700">Additional Info</legend>
          <div className="space-y-4 pt-2">
            <InputField label="Baggage Info" name="baggageInfo" value={data.baggageInfo} onChange={onChange} />
            <InputField label="Agent Info" name="agentInfo" value={data.agentInfo} onChange={onChange} />
          </div>
        </fieldset>

        <fieldset className="border border-gray-200 p-4 rounded-lg">
          <legend className="text-lg font-semibold px-2 text-gray-700">Payment</legend>
          <div className="space-y-4 pt-2">
            <InputField label="Payment Method" name="paymentMethod" value={data.paymentMethod} onChange={onChange} />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <InputField label="Fare" name="fare" value={data.fare} onChange={onChange} />
                <InputField label="Taxes" name="taxes" value={data.taxes} onChange={onChange} />
                <InputField label="Total" name="total" value={data.total} onChange={onChange} />
            </div>
          </div>
        </fieldset>
      </form>
    </div>
  );
};
