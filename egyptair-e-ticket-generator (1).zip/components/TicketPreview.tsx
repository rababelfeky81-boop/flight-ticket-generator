
import React, { forwardRef } from 'react';
import type { TicketData } from '../types';
import { EgyptAirLogo, BarcodeIcon, PlaneIcon } from './icons';

interface TicketPreviewProps {
  data: TicketData;
}

const InfoBlock: React.FC<{ label: string; value: React.ReactNode; className?: string }> = ({ label, value, className }) => (
  <div className={className}>
    <p className="text-xs text-gray-500 uppercase tracking-wider">{label}</p>
    <p className="font-semibold text-sm text-gray-900">{value}</p>
  </div>
);

export const TicketPreview = forwardRef<HTMLDivElement, TicketPreviewProps>(({ data }, ref) => {
  const formatDateTime = (dateTimeString: string) => {
    if (!dateTimeString) return { date: '', time: '' };
    const date = new Date(dateTimeString);
    return {
      date: date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase(),
      time: date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
    };
  };

  const departure = formatDateTime(data.departureDateTime);
  const arrival = formatDateTime(data.arrivalDateTime);

  return (
    <div ref={ref} className="bg-white p-6 border border-gray-200 text-sm font-mono print:border-none print:p-0">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start border-b-2 border-gray-800 pb-4">
          <div>
            <EgyptAirLogo className="h-12 w-auto" />
            <p className="text-xs text-gray-600 mt-1">A STAR ALLIANCE MEMBER</p>
          </div>
          <div className="text-right">
            <h2 className="text-xl font-bold tracking-wider">E-TICKET RECEIPT</h2>
            <InfoBlock label="Booking Reference" value={data.bookingReference} className="mt-2" />
          </div>
        </div>

        {/* Passenger Info */}
        <div className="grid grid-cols-2 gap-4">
          <InfoBlock label="Passenger Name" value={data.fullName} />
          <InfoBlock label="E-Ticket Number" value={data.ticketNumber} />
        </div>

        {/* Itinerary Header */}
        <div className="bg-gray-100 p-2 rounded-t-md border-b-2 border-red-700">
          <h3 className="font-bold text-gray-800">ITINERARY</h3>
        </div>

        {/* Flight Details */}
        <div className="border border-gray-200 rounded-b-md">
          <div className="p-4 flex items-center justify-between">
              <div className="text-center">
                  <p className="font-bold text-xl">{data.departureAirport}</p>
                  <p className="text-gray-600">{data.departureCity}</p>
              </div>
              <div className="flex-grow flex items-center justify-center text-gray-400">
                <div className="border-t border-dashed border-gray-400 w-full mx-4"></div>
                <PlaneIcon className="w-6 h-6" />
                <div className="border-t border-dashed border-gray-400 w-full mx-4"></div>
              </div>
              <div className="text-center">
                  <p className="font-bold text-xl">{data.arrivalAirport}</p>
                  <p className="text-gray-600">{data.arrivalCity}</p>
              </div>
          </div>
          <div className="bg-gray-50 grid grid-cols-4 sm:grid-cols-7 gap-4 text-center text-xs font-semibold uppercase text-gray-500 p-2 border-t border-b">
            <div>Flight</div>
            <div>Departs</div>
            <div className="hidden sm:block">Date</div>
            <div>Arrives</div>
            <div className="hidden sm:block">Date</div>
            <div>Class</div>
            <div className="hidden sm:block">Baggage</div>
          </div>
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-4 text-center text-sm p-4 items-center">
            <div className="font-semibold">{data.flightNumber}</div>
            <div className="font-semibold text-red-700">{departure.time}</div>
            <div className="hidden sm:block">{departure.date}</div>
            <div className="font-semibold text-red-700">{arrival.time}</div>
            <div className="hidden sm:block">{arrival.date}</div>
            <div>{data.flightClass}</div>
            <div className="hidden sm:block">{data.baggageInfo}</div>
          </div>
          <div className="border-t p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
              <InfoBlock label="Terminal" value={data.terminal} />
              <InfoBlock label="Duration" value={data.duration} />
              <InfoBlock label="Aircraft" value="BOEING 777" />
              <InfoBlock label="Operated by" value="EGYPTAIR" />
          </div>
        </div>

        {/* Payment Details */}
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
          <div>
            <div className="bg-gray-100 p-2 rounded-t-md border-b-2 border-red-700">
                <h3 className="font-bold text-gray-800">FARE BREAKDOWN</h3>
            </div>
            <div className="border border-t-0 rounded-b-md p-4 space-y-2">
                <div className="flex justify-between"><span>Fare:</span> <span>{data.fare}</span></div>
                <div className="flex justify-between"><span>Taxes and Fees:</span> <span>{data.taxes}</span></div>
                <div className="flex justify-between font-bold border-t pt-2 mt-2"><span>Total Amount:</span> <span>{data.total}</span></div>
            </div>
          </div>
           <div>
            <div className="bg-gray-100 p-2 rounded-t-md border-b-2 border-red-700">
                <h3 className="font-bold text-gray-800">PAYMENT DETAILS</h3>
            </div>
            <div className="border border-t-0 rounded-b-md p-4">
              <InfoBlock label="Form of Payment" value={data.paymentMethod} />
            </div>
          </div>
        </div>
        
        {/* Footer & Barcode */}
        <div className="pt-4 border-t mt-6 flex justify-between items-end">
            <div>
                 <InfoBlock label="Agent Information" value={data.agentInfo} />
                 <p className="text-xs text-gray-500 mt-4">Thank you for choosing EgyptAir. Please check-in online to save time at the airport.</p>
            </div>
             <div className="text-center">
                <BarcodeIcon className="h-12 w-auto" />
                <p className="text-xs tracking-widest">{data.ticketNumber}</p>
             </div>
        </div>

      </div>
    </div>
  );
});
