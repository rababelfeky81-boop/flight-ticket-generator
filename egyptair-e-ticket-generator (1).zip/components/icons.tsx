import React from 'react';

export const EgyptAirLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 514.8 96.7" xmlns="http://www.w3.org/2000/svg" {...props}>
      <g fill="#003366">
        <path d="M51.8 95.2H16.3V1.6h40.4v16H31.1v14.2h22.9v16H31.1v16h23.4v16.2H51.8z" />
        <path d="M119.5 95.2L103.1 52H86.2L69.8 95.2h17.5l2.5-7.2h13.5l2.5 7.2h13.5zM98 75.4l4.8-13.6 4.8 13.6H98z" />
        <path d="M126.3 95.2V1.6h16.4v93.6h-16.4z" />
        <path d="M150.3 95.2V1.6h51.1v16h-34.7v22.4h30.8v16h-30.8v33.2h-16.4z" />
        <path d="M210.1 95.2V1.6h16.4v93.6h-16.4z" />
        <path d="M233.2 95.2V1.6h16.4v62.2h29.2v15.2h-45.6V95.2z" />
        <path d="M285.3 95.2V1.6h16.4v93.6h-16.4z" />
        <path d="M308.5 95.2V1.6h40.4v16h-24v14.2h21.5v16h-21.5v16h24.3v16.2h-40.7z" />
        <path d="M441.9 48.4c0-22.3 16.9-40.6 40.4-40.6s40.4 18.2 40.4 40.6-16.9 40.6-40.4 40.6-40.4-18.3-40.4-40.6zm62.1 0c0-12.4-9.1-23.3-21.7-23.3s-21.7 10.9-21.7 23.3 9.1 23.3 21.7 23.3 21.7-10.9 21.7-23.3z" />
        <path d="M397.7 51.5c-1.6-1.6-3.7-2.7-6-3-4-0.6-8 0.1-11.7 2.2-1.2 0.7-2.3 1.6-3.4 2.6-3.5 3.4-6.2 7.7-7.5 12.5-0.8 2.9-1.2 6-1.2 9 0 2.7 0.4 5.3 1 7.9 1.1 4.2 3.1 8.2 5.9 11.5 1.1 1.3 2.3 2.4 3.6 3.5 3.3 2.7 7.1 4.5 11.4 5.2 2.5 0.5 5.1 0.5 7.6 0.1 5.7-0.8 10.9-3.6 15.1-7.8 3.8-3.8 6.2-8.6 7-14 0.4-2.3 0.5-4.6 0.1-6.9-0.6-4.1-2.3-7.9-5-11.3-2.2-2.7-4.9-4.8-8-6.3-2.3-1.1-4.7-1.8-7.3-2.2zm-21.4-12.6c-2 0-3.9-0.2-5.7-0.7-5.2-1.3-9.7-4.4-12.9-8.7-2.8-3.9-4.4-8.5-4.4-13.3 0-2.9 0.5-5.8 1.5-8.6 0.6-1.8 1.4-3.5 2.4-5.2 0.1-0.2 0.4-0.4 0.6-0.5 0.5-0.2 1-0.2 1.5 0 1.1 0.5 1.6 1.7 1.1 2.8-0.7 1.6-1.3 3.2-1.8 4.7-0.7 2.4-1.1 5-1.1 7.5 0 4 1.3 7.8 3.5 11 2.8 3.8 6.5 6.4 11 7.4 1.8 0.4 3.6 0.6 5.4 0.6 1.1 0 2.1-0.9 2.1-2.1 0-1.1-0.9-2.1-2.1-2.1z" />
        <path d="M372.6 30.1c-0.1-1-0.1-1.9-0.2-2.8-0.2-2.5-0.9-5-1.8-7.4-1.2-2.9-3-5.6-5.2-7.8-1.5-1.5-3-2.7-4.8-3.6-1.3-0.7-2.7-1.3-4.1-1.8-0.1 0-0.2-0.1-0.4-0.1-0.2-0.1-0.6-0.1-0.8 0-0.2 0.1-0.5 0.2-0.6 0.4s-0.2 0.5-0.1 0.7c0.1 0.5 0.4 0.9 0.7 1.1 1.3 0.8 2.5 1.8 3.7 2.8 1.8 1.6 3.4 3.4 4.6 5.6 1 1.8 1.6 3.8 2.1 5.8 0.2 1.2 0.4 2.4 0.4 3.6 0 0.2 0 0.6 0.1 0.8 0 0.1 0.1 0.4 0.2 0.4 0.2 0.2 0.6 0.2 0.8 0.1 0.4-0.1 0.7-0.5 0.7-0.8z" />
        <path d="M391.7 41c-0.7-1-1.6-1.8-2.5-2.5-2.3-1.7-4.8-2.9-7.6-3.5-2.2-0.5-4.4-0.6-6.5-0.4-2.5 0.2-5.1 1-7.4 2.1-1.5 0.7-2.9 1.6-4.2 2.7-0.2 0.2-0.4 0.5-0.5 0.7-0.1 0.2-0.1 0.6 0 0.8 0.1 0.2 0.2 0.5 0.5 0.6 0.2 0.1 0.5 0.2 0.7 0.1 0.5-0.1 0.9-0.5 1.1-0.8 1.1-1 2.3-1.7 3.6-2.3 2-1 4.2-1.6 6.4-1.8 1.9-0.2 3.8-0.1 5.7 0.2 2.5 0.6 4.8 1.7 6.9 3.2 0.7 0.5 1.4 1.1 2.1 1.8 0.2 0.2 0.5 0.4 0.8 0.4 0.2 0 0.5-0.1 0.6-0.2 0.4-0.4 0.4-1 0-1.4z" />
        <path d="M409 65.5c0.6-1.6 1-3.2 1.1-4.8-0.2-5-2.2-9.6-5.5-13.2-3-3.4-7-5.7-11.4-6.7-2.5-0.6-5.1-0.7-7.6-0.5-4.6 0.5-8.9 2.3-12.6 5.2-1.6 1.2-3 2.7-4.2 4.2-0.1 0.2-0.2 0.5-0.1 0.7 0 0.2 0.1 0.5 0.2 0.6 0.1 0.1 0.4 0.2 0.6 0.2 0.2 0 0.5-0.1 0.6-0.2 0.4-0.4 0.7-0.7 1.1-1.1 1.1-1.3 2.3-2.5 3.6-3.5 3.3-2.5 7-4.1 11-4.5 2.3-0.2 4.6-0.1 6.9 0.5 3.9 0.8 7.4 2.9 10.2 5.8 2.8 3 4.5 6.9 4.8 11 0 1.5-0.2 2.9-0.7 4.4-0.1 0.5 0.1 1 0.6 1.2 0.5 0.1 1-0.1 1.2-0.6z" />
      </g>
    </svg>
);

export const PlaneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M2 21h10l7-8-7-8H2l4 8-4 8z" />
    <path d="M21.5 12H12" />
  </svg>
);

export const BarcodeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 120 40" xmlns="http://www.w3.org/2000/svg" {...props}>
        <rect x="0" y="0" width="2" height="40" fill="black" />
        <rect x="4" y="0" width="1" height="40" fill="black" />
        <rect x="7" y="0" width="3" height="40" fill="black" />
        <rect x="12" y="0" width="1" height="40" fill="black" />
        <rect x="15" y="0" width="2" height="40" fill="black" />
        <rect x="19" y="0" width="1" height="40" fill="black" />
        <rect x="22" y="0" width="4" height="40" fill="black" />
        <rect x="28" y="0" width="2" height="40" fill="black" />
        <rect x="32" y="0" width="1" height="40" fill="black" />
        <rect x="35" y="0" width="3" height="40" fill="black" />
        <rect x="40" y="0" width="1" height="40" fill="black" />
        <rect x="43" y="0" width="2" height="40" fill="black" />
        <rect x="47" y="0" width="1" height="40" fill="black" />
        <rect x="50" y="0" width="3" height="40" fill="black" />
        <rect x="55" y="0" width="2" height="40" fill="black" />
        <rect x="59" y="0" width="1" height="40" fill="black" />
        <rect x="62" y="0" width="4" height="40" fill="black" />
        <rect x="68" y="0" width="1" height="40" fill="black" />
        <rect x="71" y="0" width="2" height="40" fill="black" />
        <rect x="75" y="0" width="3" height="40" fill="black" />
        <rect x="80" y="0" width="1" height="40" fill="black" />
        <rect x="83" y="0" width="2" height="40" fill="black" />
        <rect x="87" y="0" width="1" height="40" fill="black" />
        <rect x="90" y="0" width="4" height="40" fill="black" />
        <rect x="96" y="0" width="2" height="40" fill="black" />
        <rect x="100" y="0" width="1" height="40" fill="black" />
        <rect x="103" y="0" width="3" height="40" fill="black" />
        <rect x="108" y="0" width="1" height="40" fill="black" />
        <rect x="111" y="0" width="2" height="40" fill="black" />
        <rect x="115" y="0" width="1" height="40" fill="black" />
        <rect x="118" y="0" width="2" height="40" fill="black" />
    </svg>
);


export const PrintIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <polyline points="6 9 6 2 18 2 18 9"></polyline>
    <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
    <rect x="6" y="14" width="12" height="8"></rect>
  </svg>
);
